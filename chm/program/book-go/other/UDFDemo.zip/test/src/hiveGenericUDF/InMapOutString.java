package hiveGenericUDF;

import java.util.Iterator;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.MapObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;
/**
 * @author xingzhou
	add jar file:///home/aueic/xz/xx.jar ;
	
	create temporary function test as 'hiveGenericUDF.InMapOutString';
	
	select test(map("1","11","2","22","3","33"));
	ע��map ��key value������ 
 */
public class InMapOutString extends GenericUDF{
	private ObjectInspector[] objectInspectors ;
	@Override
	public ObjectInspector initialize(ObjectInspector[] arguments)
			throws UDFArgumentException {
		objectInspectors = arguments ;
		return PrimitiveObjectInspectorFactory.javaStringObjectInspector;
	}

	@Override
	public Object evaluate(DeferredObject[] arguments) throws HiveException {
		MapObjectInspector mapObjectInspector = (MapObjectInspector)objectInspectors[0] ;
		Object mapObject = arguments[0].get() ;
		Map<Text, Text> map = (Map<Text, Text>) mapObjectInspector.getMap(mapObject) ;
		Iterator<Text> it = map.keySet().iterator() ;
		StringBuffer sb = new StringBuffer() ;
		String ret = "" ;
		while (it.hasNext()) {
			Text key = it.next() ;
			Text value = map.get(key) ;
			sb.append(",").append(key.toString()).append(":").append(value.toString()) ;
		}
		if(sb.length()>0){
			ret = sb.substring(1) ;
		}
		return ret;
	}

	@Override
	public String getDisplayString(String[] children) {
		StringBuffer sb = new StringBuffer() ;
		for (int i = 0; i < children.length; i++) {
			sb.append(children[0]) ;
		}
		return sb.toString();
	}

}

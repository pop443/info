package hiveGenericUDF;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ListObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;
/**
 * @author xingzhou
	add jar file:///home/aueic/xz/xx.jar ;
	
	create temporary function test as 'hiveGenericUDF.InListOutString';
	
	select test(split("11,22,33,44",","));
	
 */
public class InListOutString extends GenericUDF{
	private ObjectInspector[] objectInspectors ;
	@Override
	public ObjectInspector initialize(ObjectInspector[] arguments)
			throws UDFArgumentException {
		objectInspectors = arguments ;
		return PrimitiveObjectInspectorFactory.javaStringObjectInspector ;
	}

	@Override
	public Object evaluate(DeferredObject[] arguments) throws HiveException {
		ListObjectInspector listObjectInspector = (ListObjectInspector)objectInspectors[0] ;
		Object array = arguments[0].get();
		int length = listObjectInspector.getListLength(array) ;
		
		StringBuffer sb = new StringBuffer() ;
		String ret = "" ;
		for (int i = 0; i < length; i++) {
			Object listElement = listObjectInspector.getListElement(array, i);
			Text s = (Text)listElement ;
			sb.append("-"+s.toString()) ;
		}
		if(sb.length()>0){
			ret = sb.substring(1) ;
		}
		
		return ret ;
	}

	@Override
	public String getDisplayString(String[] children) {
		StringBuffer sb = new StringBuffer() ;
		for (int i = 0; i < children.length; i++) {
			sb.append(children[i]) ;
		}
		return sb.toString();
	}

}

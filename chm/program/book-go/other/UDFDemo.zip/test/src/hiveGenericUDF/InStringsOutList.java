package hiveGenericUDF;

import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.io.Text;
/**
 * @author xingzhou
	add jar file:///home/aueic/xz/xx.jar ;
	
	create temporary function test as 'hiveGenericUDF.InStringsOutList';
	
	select t.tt[0],t.tt[1],t.tt[2] from (select test("33,44,55","66,77","88") tt ) t; 

 */
public class InStringsOutList extends GenericUDF {
	private ObjectInspector[] objectInspectors;

	@Override
	public ObjectInspector initialize(ObjectInspector[] arguments)
			throws UDFArgumentException {
		objectInspectors = arguments;
		return ObjectInspectorFactory
				.getStandardListObjectInspector(PrimitiveObjectInspectorFactory.writableStringObjectInspector);
	}

	@Override
	public Object evaluate(DeferredObject[] arguments) throws HiveException {
		List<Text> list = new ArrayList<>() ;
		
		for (int i = 0; i < arguments.length; i++) {
			String s = ((StringObjectInspector) objectInspectors[i])
					.getPrimitiveJavaObject(arguments[i].get());
			list.add(new Text(s)) ;
		}
		return list;
	}

	@Override
	public String getDisplayString(String[] children) {
		StringBuffer sb = new StringBuffer() ;
		for (int i = 0; i < children.length; i++) {
			sb.append(children[i]) ;
		}
		return sb.toString() ;
	}

}

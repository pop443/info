package hiveGenericUDF;

import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
/**
 * @author xingzhou
	add jar file:///home/aueic/xz/xx.jar ;
	
	create temporary function test as 'hiveGenericUDF.InStringOutMap';
	
	select key,value from (select test("33,44,55") tt ) t 
	lateral view explode(t.tt) columns as key,value ;
 */
public class InStringOutMap extends GenericUDF {
	private ObjectInspector[] oiArray;
	@Override
	public ObjectInspector initialize(ObjectInspector[] arguments)
			throws UDFArgumentException {
		oiArray = arguments ;
		return ObjectInspectorFactory.getStandardMapObjectInspector(
				PrimitiveObjectInspectorFactory.writableIntObjectInspector,
				PrimitiveObjectInspectorFactory.writableStringObjectInspector);
	}

	@Override
	public Object evaluate(DeferredObject[] arguments) throws HiveException {
		String arg1 = ((StringObjectInspector)oiArray[0]).getPrimitiveJavaObject(arguments[0].get()) ;
		Map<IntWritable, Text> map = new HashMap<>() ;
		if(arg1.indexOf(",")<0){
			map.put(new IntWritable(1), new Text(arg1)) ;
			return map ;
		}
		String[] strings = arg1.split(",") ;
		for (int i = 0; i < strings.length; i++) {
			IntWritable iw = new IntWritable(i+1) ;
			Text text = new Text(strings[i]) ;
			map.put(iw, text) ;
		}
		return map;
	}

	@Override
	public String getDisplayString(String[] children) {
		StringBuffer sb = new StringBuffer() ;
		for (int i = 0; i < children.length; i++) {
			sb.append(children[0]) ;
		}
		return sb.toString();
	}

}

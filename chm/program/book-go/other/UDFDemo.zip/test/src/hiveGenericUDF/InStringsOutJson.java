package hiveGenericUDF;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.StringObjectInspector;
import org.apache.hadoop.io.Text;
import org.json.JSONException;
import org.json.JSONObject;
/**
 * @author xingzhou
	add jar file:///home/aueic/xz/xx.jar ;
	
	create temporary function test as 'hiveGenericUDF.InStringsOutJson';
	
	select index1,index2,index3 from (select test("33","44","55") tt ) t 
	lateral view json_tuple(t.tt,'VALUE1','VALUE2','VALUE3') 
	columns as index1,index2,index3 ;
 */
public class InStringsOutJson extends GenericUDF{
	private ObjectInspector[] oiArray;
	private Text text = new Text() ;
	@Override
	public ObjectInspector initialize(ObjectInspector[] arguments)
			throws UDFArgumentException {
		oiArray = arguments;
		return  PrimitiveObjectInspectorFactory.writableStringObjectInspector;
	}

	@Override
	public Object evaluate(DeferredObject[] arguments) throws HiveException {
		String paraMdata1 = ((StringObjectInspector) oiArray[0])
				.getPrimitiveJavaObject(arguments[0].get());
		String paraMdata2 = ((StringObjectInspector) oiArray[1])
				.getPrimitiveJavaObject(arguments[1].get());
		String paraMdata3 = ((StringObjectInspector) oiArray[2])
				.getPrimitiveJavaObject(arguments[2].get());
		try {
			JSONObject jsonObject = new JSONObject() ;
			jsonObject.put("VALUE1", paraMdata1) ;
			jsonObject.put("VALUE2", paraMdata2) ;
			jsonObject.put("VALUE3", paraMdata3) ;
			String s = jsonObject.toString() ;
			text.set(s);
			return text;
		} catch (JSONException e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	@Override
	public String getDisplayString(String[] children) {
		StringBuffer sb = new StringBuffer() ;
		for (int i = 0; i < children.length; i++) {
			sb.append(children[i]) ;
		}
		return sb.toString();
	}

}

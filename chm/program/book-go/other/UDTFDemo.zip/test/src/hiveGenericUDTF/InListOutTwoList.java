package hiveGenericUDTF;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ListObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
/**
 * 
 * @author xz
 * add jar file:///home/aueic/xz/xx.jar ;
	
	create temporary function test as 'hiveGenericUDTF.InListOutTwoList';
	
	select test(split("1,'2',3.5",","))
 *
 */
public class InListOutTwoList  extends GenericUDTF{
	private ObjectInspector[] oiArray;
	@Override
	public StructObjectInspector initialize(ObjectInspector[] argOIs)
			throws UDFArgumentException {
		this.oiArray = argOIs ;
		List<String> fieldNames = new ArrayList<String>();
		List<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>();
		fieldNames.add("fieldname") ;
		fieldNames.add("fieldvalue") ;
		fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
		fieldOIs.add(PrimitiveObjectInspectorFactory.javaIntObjectInspector);
		return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);
	}

	@Override
	public void process(Object[] args) throws HiveException {
		List<?> list = ((ListObjectInspector)oiArray[0]).getList(args[0]) ;
		Object[] forwardObj = new Object[2];
		for (int i = 0; i < list.size(); i++) {
			forwardObj[0] = list.get(i).toString() ;
			forwardObj[1] = i ;
			super.forward(forwardObj);
		}
	}

	@Override
	public void close() throws HiveException {
		// TODO Auto-generated method stub
		
	}

}

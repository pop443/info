package hiveGenericUDTF;

import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.IntObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
/**
 * 
 * @author xz
 * add jar file:///home/aueic/xz/xx.jar ;
	
	create temporary function test as 'hiveGenericUDTF.InIntsOutList';
	
	with tmp as (select 1 id union all select 2 id),
	tmp1 as (select test(0,5))
	select * from tmp1 join tmp on 1=1
 *
 */
public class InIntsOutList extends GenericUDTF{
	
	private ObjectInspector[] oiArray;
	
	@Override
	public StructObjectInspector initialize(ObjectInspector[] argOIs)
			throws UDFArgumentException {
		this.oiArray = argOIs ;
		List<String> fieldNames = new ArrayList<String>();
		List<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>();
		fieldNames.add("fiename") ;
		fieldOIs.add(PrimitiveObjectInspectorFactory.javaIntObjectInspector) ;
		return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);
	}

	@Override
	public void process(Object[] o) throws HiveException {
		int i1 = ((IntObjectInspector)this.oiArray[0]).get(o[0]) ;
		int i2 = ((IntObjectInspector)this.oiArray[1]).get(o[1]) ;
		Object[] forwardListObj = new Object[1];
		for (int i = i1; i < i2; i++) {
			forwardListObj[0] = i ;
			super.forward(forwardListObj);
		}
		
	}

	@Override
	public void close() throws HiveException {
		// TODO Auto-generated method stub
		
	}

}
